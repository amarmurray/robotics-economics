"""Scoped, exact tests for manufacturing learning/capital allocation; no industry calibration."""
import json
import unittest
from dataclasses import replace
from fractions import Fraction as F
from manufacturing import Market, Supply, optimize, specialized_threshold, scenarios, to_json


A=Market(F(15),F(2),F(3),F(4))
B=Market(F(19),F(2),F(3),F(3))
POOR=Market(F(10),F(2),F(3),F(4))
RICH=Market(F(22),F(2),F(3),F(3))


class ManufacturingTests(unittest.TestCase):
    def test_customer_quantity_response(self):
        m=Market(F(11),F(2),F(3),F(0))
        self.assertEqual(m.adopted(F(1))[0],F(1))
        self.assertEqual(m.adopted(F(9))[0],F(4))

    def test_outside_option(self):
        self.assertEqual(Market(F(11),F(2),F(3),F(1000)).adopted(F(4)),(F(0),F(0),F(1000)))

    def test_profit_sharing(self):
        q,p,c=Market(F(11),F(2),F(3),F(2),F(4,5)).adopted(F(2))
        self.assertEqual((q,p,c),(F(2),F(8),F(4)))

    def test_resource_and_price_separate(self):
        no=replace(Supply(),pass_through=F(0)).unit_prices(2)
        full=Supply().unit_prices(2)
        self.assertEqual(no,(F(6),F(9),F(3),F(4)))
        self.assertEqual(full,(F(4),F(5),F(3),F(4)))

    def test_supplier_margin_incidence(self):
        prices=[replace(Supply(),pass_through=k).unit_prices(2) for k in (F(0),F(1,2),F(1))]
        self.assertEqual([p[0]-p[2] for p in prices],[F(3),F(2),F(1)])
        self.assertEqual([p[1]-p[3] for p in prices],[F(5),F(3),F(1)])

    def test_tooling_separate_not_history(self):
        s=Supply()
        plain=s.unit_prices(1,False); tooled=s.unit_prices(1,True)
        self.assertEqual(tuple(a-b for a,b in zip(plain,tooled)),(F(1),)*4)
        self.assertEqual(s.invoice_g,F(6))

    def test_threshold_exact(self):
        m=Market(F(14),F(2),F(3),F(3))
        self.assertEqual(specialized_threshold(m,Supply(),0),F(49,4))
        self.assertEqual(specialized_threshold(m,Supply(),2),F(39,4))
        self.assertEqual(specialized_threshold(m,replace(Supply(),pass_through=F(0)),2),F(49,4))

    def test_threshold_reversed_by_component_learning(self):
        m=Market(F(14),F(2),F(3),F(3))
        self.assertEqual(specialized_threshold(m,replace(Supply(),learning_s=F(1,2)),2),F(27,2))

    def test_threshold_pairwise_exact_check(self):
        s=Supply()
        for x in (0,1,2):
            pg,ps,_,_=s.unit_prices(x)
            t=specialized_threshold(Market(F(14),F(2),F(3),F(3)),s,x)
            for sign in (-1,0,1):
                a=t+F(sign,10)
                m=Market(a,F(2),F(3),F(3))
                qg,vg,_=m.adopted(s.g_capacity_b)
                qs,vs,_=m.adopted(s.s_capacity_b)
                self.assertEqual((qg,qs),(s.g_capacity_b,s.s_capacity_b))
                delta=(vs-ps-s.specialized_design)-(vg-pg)
                self.assertEqual((delta>0)-(delta<0),sign)

    def test_provider_optimal_budget_monotonic(self):
        for k in (F(0),F(1)):
            s=replace(Supply(),pass_through=k)
            vals=[optimize(F(b),A,B,s).provider_net_value for b in range(0,21)]
            self.assertTrue(all(x<=y for x,y in zip(vals,vals[1:])))

    def test_pass_through_weakly_improves_deployer_optimum(self):
        for b in (F(9),F(14),F(18),F(22)):
            vals=[optimize(b,A,B,replace(Supply(),pass_through=k)).provider_net_value
                  for k in (F(0),F(1,2),F(1))]
            self.assertTrue(all(x<=y for x,y in zip(vals,vals[1:])))

    def test_redeployment_option_weakly_improves_value(self):
        for b in (F(12),F(18)):
            no=optimize(b,POOR,RICH,allow_tooling=False)
            yes=optimize(b,POOR,RICH,allow_tooling=False,allow_redeployment=True)
            self.assertGreaterEqual(yes.provider_net_value,no.provider_net_value)

    def test_tooling_option_weakly_improves_value(self):
        for k in (F(0),F(1)):
            s=replace(Supply(),pass_through=k)
            no=optimize(F(14),A,B,s,allow_tooling=False)
            yes=optimize(F(14),A,B,s,allow_tooling=True)
            self.assertGreaterEqual(yes.provider_net_value,no.provider_net_value)

    def test_no_specialization_when_forbidden(self):
        self.assertEqual(optimize(F(18),POOR,RICH,allow_specialization=False).sb,0)

    def test_source_seeding_policy(self):
        sc=scenarios()['source_seeding']
        self.assertEqual((sc['no_destination_demand'].n0,sc['high_destination_full_pass_through'].n0,
                          sc['high_destination_no_pass_through'].n0,sc['high_destination_no_learning'].n0),
                         (0,2,0,0))
        self.assertEqual(sc['high_destination_full_pass_through'].provider_net_value,F(67,5))
        self.assertEqual(sc['high_destination_no_pass_through'].provider_net_value,F(59,5))

    def test_seeding_cash_threshold(self):
        # With 2 source units: stage-one cash = 18 -12 + 24/5 = 54/5.
        # Target specialized unit + entry/design costs = 13 - 4*kappa.
        self.assertEqual((F(13)-F(54,5))/4,F(11,20))
        # Holding the same future specialized choice, provider seed premium
        # = 2*(24/5)-12+4*kappa, so strict value switch occurs at kappa>3/5.
        self.assertEqual((F(12)-2*F(24,5))/4,F(3,5))
        for k,n0 in ((F(1,2),0),(F(3,5),0),(F(2,3),2)):
            d=optimize(F(18),POOR,RICH,replace(Supply(),pass_through=k),allow_tooling=False)
            self.assertEqual(d.n0,n0)

    def test_supplier_value_capture_separate_from_provider(self):
        d=optimize(F(18),POOR,RICH,Supply(),allow_tooling=False)
        self.assertEqual(d.supplier_net_margin,F(3))
        self.assertEqual(d.t0_hardware_invoice,F(12))
        self.assertEqual(d.t1_unit_invoice,F(5))
        self.assertEqual(d.qualification_and_entry,F(4))

    def test_cash_and_terminal_reconcile(self):
        for k in (F(0),F(1,2),F(1)):
            for sal in (F(0),F(1,4)):
                s=replace(Supply(),pass_through=k,salvage_share=sal)
                d=optimize(F(18),POOR,RICH,s,allow_redeployment=True)
                self.assertGreaterEqual(d.cash_after_t0,d.t1_total_investment)
                total=d.cash_after_t0-d.t1_total_investment+d.t1_provider_receipt+d.salvage
                self.assertEqual(total,F(18)+d.provider_net_value)

    def test_salvage_never_pays_upfront(self):
        s=replace(Supply(),salvage_share=F(9,10))
        d=optimize(F(0),A,B,s)
        self.assertEqual((d.n0,d.ga,d.gb,d.sb,d.t1_total_investment),(0,0,0,0,F(0)))

    def test_manual_enumeration_single_source(self):
        # No t0 purchase possible and one-period t1 purchases exactly tested.
        s=replace(Supply(),max_t0=0,max_t1=1)
        m=optimize(F(14),POOR,RICH,s,allow_tooling=False)
        alternatives=[F(0),POOR.adopted(F(1))[1]-s.invoice_g,
                      RICH.adopted(F(1))[1]-s.invoice_g-s.entry_cost,
                      RICH.adopted(F(2))[1]-s.invoice_s-s.entry_cost-s.specialized_design]
        self.assertEqual(m.provider_net_value,max(alternatives))

    def test_adverse_generalist_transfer_affects_specialization_threshold(self):
        m=Market(F(14),F(2),F(3),F(3))
        s=replace(Supply(),learning_s=F(1,2))
        self.assertGreater(specialized_threshold(m,s,2),specialized_threshold(m,s,0))

    def test_finite_saturation(self):
        high=Market(F(7),F(2),F(3),F(0))
        self.assertEqual(high.adopted(F(99))[0],F(2))

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError): Market(F(10),F(0),F(1),F(0))
        with self.assertRaises(ValueError): Supply(pass_through=F(2))
        with self.assertRaises(ValueError): Supply(resource_g=F(0))
        with self.assertRaises(ValueError): optimize(F(-1),A,B)
        with self.assertRaises(ValueError): specialized_threshold(B,replace(Supply(),g_capacity_b=F(2)),0)

    def test_deterministic_output(self):
        self.assertEqual(json.dumps(to_json(scenarios()),sort_keys=True),json.dumps(to_json(scenarios()),sort_keys=True))


if __name__=='__main__': unittest.main()
