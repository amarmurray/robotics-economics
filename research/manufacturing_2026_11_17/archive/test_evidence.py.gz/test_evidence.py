"""Validate scope/provenance of sparse source records; no fabricated observed learning rates."""
import json
import pathlib
import unittest

D=json.loads(pathlib.Path(__file__).with_name('evidence.json').read_text())


class EvidenceTests(unittest.TestCase):
    def test_unique_sources_and_relation_ids(self):
        self.assertEqual(len({x['id'] for x in D['sources']}),len(D['sources']))
        self.assertEqual(len({x['id'] for x in D['relations']}),len(D['relations']))

    def test_all_observed_edges_have_real_source(self):
        src={x['id'] for x in D['sources']}
        for e in D['relations']:
            if e['status'].startswith(('issuer','IFR')):
                self.assertIn(e['source'],src)

    def test_unknown_network_links_remain_null(self):
        for e in D['relations']:
            if e['status'] in ('unmeasured_hypothesis','unobserved_contract_link','unidentified'):
                self.assertIsNone(e['source'])
                for key in ('learning_slope','pass_through_fraction','relative_saving','customer_contribution_and_revenue'):
                    if key in e:self.assertIsNone(e[key])

    def test_nameplate_not_reported_realized(self):
        a=next(x for x in D['relations'] if x['id']=='E4')
        self.assertIsNone(a['realized_production_2025'])
        self.assertIn('nameplate',a['type'])

    def test_no_humanoid_split_from_ifr(self):
        for x in D['relations']:
            if x['source']=='M3':self.assertIsNone(x['humanoid_subset'])

    def test_sources_are_vintaged_and_linked(self):
        for x in D['sources']:
            self.assertTrue(x['url'].startswith('https://'))
            self.assertTrue(x.get('event_date') or x.get('publication_date'))

if __name__=='__main__':unittest.main()
