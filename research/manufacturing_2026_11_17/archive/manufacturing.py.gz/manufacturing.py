"""Exact synthetic dynamic model: manufacturer learning, invoice incidence, embodiment investment.
Python 3.10+ standard library. All numerical inputs are hypothetical, never calibrated.
"""
from __future__ import annotations
from dataclasses import dataclass, replace, asdict
from fractions import Fraction as F
from typing import Any
import argparse
import json


@dataclass(frozen=True)
class Market:
    a: F
    b: F
    c: F
    outside: F
    rho: F = F(4, 5)
    def __post_init__(self):
        if self.b <= 0 or self.c < 0 or self.outside < 0 or not F(0)<=self.rho<=F(1):
            raise ValueError('Invalid market')
    def adopted(self, capacity:F) -> tuple[F,F,F]:
        if capacity < 0: raise ValueError('Negative capacity')
        q=min(capacity,max(F(0),(self.a-self.c)/self.b))
        gross=(self.a-self.c)*q-self.b*q*q/2
        if gross<=self.outside: return F(0),F(0),self.outside
        net=gross-self.outside
        return q,self.rho*net,self.outside+(1-self.rho)*net


@dataclass(frozen=True)
class Supply:
    invoice_g:F=F(6)
    invoice_s:F=F(9)
    resource_g:F=F(5)
    resource_s:F=F(8)
    learning_g:F=F(1)
    learning_s:F=F(2)
    pass_through:F=F(1)
    specialized_design:F=F(2)
    entry_cost:F=F(2)
    tooling_cost:F=F(2)
    tooling_saving_g:F=F(1)
    tooling_saving_s:F=F(1)
    salvage_share:F=F(0)
    g_capacity_b:F=F(1)
    s_capacity_b:F=F(2)
    max_t0:int=2
    max_t1:int=4
    def __post_init__(self):
        if any(x<0 for x in [self.learning_g,self.learning_s,self.specialized_design,self.entry_cost,self.tooling_cost,self.tooling_saving_g,self.tooling_saving_s]):
            raise ValueError('Costs and learning must be nonnegative')
        if not 0<=self.pass_through<=1 or not 0<=self.salvage_share<1:
            raise ValueError('Invalid fractions')
        if self.invoice_g<=0 or self.invoice_s<=0 or self.resource_g<=0 or self.resource_s<=0 or self.g_capacity_b<=0 or self.s_capacity_b<=0:
            raise ValueError('Positive costs and capacities required')
        if min(self.max_t0,self.max_t1)<0: raise ValueError('Invalid unit caps')
        if self.invoice_g < self.resource_g or self.invoice_s < self.resource_s:
            raise ValueError('Base supplier margins negative')
        if self.invoice_g-self.learning_g*self.max_t0 <=self.tooling_saving_g or self.invoice_s-self.learning_s*self.max_t0<=self.tooling_saving_s:
            raise ValueError('Learning/tooling would make positive invoice impossible')
        if self.resource_g-self.learning_g*self.max_t0<=0 or self.resource_s-self.learning_s*self.max_t0<=0:
            raise ValueError('Resource cost would become nonpositive')

    def unit_prices(self,experience:int,tooling:bool=False) -> tuple[F,F,F,F]:
        if experience<0 or experience>self.max_t0: raise ValueError('Invalid experience')
        # Supplier resource learning and invoice pass-through are different variables.
        rg=self.resource_g-self.learning_g*experience
        rs=self.resource_s-self.learning_s*experience
        pg=self.invoice_g-self.pass_through*self.learning_g*experience-int(tooling)*self.tooling_saving_g
        ps=self.invoice_s-self.pass_through*self.learning_s*experience-int(tooling)*self.tooling_saving_s
        # Tooling cost saving is fully paid through to customer and is also a real resource saving.
        rg-=int(tooling)*self.tooling_saving_g
        rs-=int(tooling)*self.tooling_saving_s
        if min(pg,ps,rg,rs)<=0 or pg<rg or ps<rs:
            raise ValueError('Unsupported margin/price case')
        return pg,ps,rg,rs


@dataclass(frozen=True)
class Choice:
    n0:int
    ga:int
    redeployed_g:int
    gb:int
    sb:int
    tooling:bool
    cash_after_t0:F
    t0_provider_receipt:F
    t1_provider_receipt:F
    t0_hardware_invoice:F
    t1_total_investment:F
    t1_unit_invoice:F
    qualification_and_entry:F
    salvage:F
    provider_net_value:F
    supplier_net_margin:F
    t0_accepted_output:F
    t1_accepted_a:F
    t1_accepted_b:F


def optimize(initial_cash:F, market_a:Market, market_b:Market, supply:Supply=Supply(),
             allow_specialization:bool=True,allow_tooling:bool=True,
             allow_expansion:bool=True,allow_redeployment:bool=False) -> Choice:
    if initial_cash<0:raise ValueError('Negative initial liquidity')
    best=None
    for n0 in range(supply.max_t0+1):
        paid0=supply.invoice_g*n0
        if paid0>initial_cash:continue
        q0, cash0, _=market_a.adopted(F(n0))
        b1=initial_cash-paid0+cash0
        for tool in (False,True) if allow_tooling else (False,):
            pg,ps,rg,rs=supply.unit_prices(n0,tool)
            for redeploy in range(n0+1) if allow_redeployment else (0,):
                for ga in range(supply.max_t1+1 if allow_expansion else 1):
                    for gb in range(supply.max_t1-ga+1 if allow_expansion else 1):
                        sb_range=range(supply.max_t1-ga-gb+1) if (allow_specialization and allow_expansion) else (0,)
                        for sb in sb_range:
                            unit_invoice=pg*(ga+gb)+ps*sb
                            qualifications=supply.entry_cost*int(redeploy+gb+sb>0)+supply.specialized_design*int(sb>0)
                            investment=unit_invoice+qualifications+supply.tooling_cost*int(tool)
                            if investment>b1:continue
                            qa,pr_a,_=market_a.adopted(F(n0-redeploy+ga))
                            qb,pr_b,_=market_b.adopted(supply.g_capacity_b*(gb+redeploy)+supply.s_capacity_b*sb)
                            salvage=supply.salvage_share*(paid0+unit_invoice)
                            provider=cash0+pr_a+pr_b-paid0-investment+salvage
                            supplier=n0*(supply.invoice_g-supply.resource_g)+(ga+gb)*(pg-rg)+sb*(ps-rs)
                            d=Choice(n0,ga,redeploy,gb,sb,tool,b1,cash0,pr_a+pr_b,paid0,investment,unit_invoice,qualifications,salvage,provider,supplier,q0,qa,qb)
                            # Exact ties favor fewer commitments and simpler configurations.
                            key=lambda x:(x.provider_net_value,-x.t1_total_investment-x.t0_hardware_invoice,-x.sb,-x.gb,-x.ga,-int(x.tooling),-x.redeployed_g,-x.n0)
                            if best is None or key(d)>key(best):best=d
    assert best is not None
    return best


def specialized_threshold(m:Market,supply:Supply,experience:int,salvage:F=F(0)) -> F:
    """B demand intercept a_B threshold: ONE S versus ONE G given B entry fee cancels.

    Only under both configurations adopted and capacity binding, with the same resource c,
    and no displaced A option or multi-unit combination. Eligibility, financing separate.
    """
    pg,ps,_,_=supply.unit_prices(experience,False)
    kg,ks=supply.g_capacity_b,supply.s_capacity_b
    if ks<=kg:raise ValueError('Specialized embodiment must have higher accepted output')
    return m.c + m.b*(kg+ks)/2 + ((1-salvage)*(ps-pg)+supply.specialized_design)/(m.rho*(ks-kg))


def scenarios():
    a=Market(F(15),F(2),F(3),F(4))
    cases={}
    for demand in (F(13),F(16),F(19),F(22)):
        b=Market(demand,F(2),F(3),F(3))
        for passthrough in (F(0),F(1,2),F(1)):
            s=replace(Supply(),pass_through=passthrough)
            d=optimize(F(14),a,b,s)
            cases[f'demand_{demand}_pass_{passthrough}']=d
    s=Supply()
    thresholds={
        'before_manufacturing_experience':specialized_threshold(Market(F(14),F(2),F(3),F(3)),s,0),
        'after_two_units_with_pass_through':specialized_threshold(Market(F(14),F(2),F(3),F(3)),s,2),
        'after_two_units_without_pass_through':specialized_threshold(Market(F(14),F(2),F(3),F(3)),replace(s,pass_through=F(0)),2),
        'reverse_transfer_after_two_units':specialized_threshold(Market(F(14),F(2),F(3),F(3)),replace(s,learning_s=F(1,2)),2),
    }
    poor_source=Market(F(10),F(2),F(3),F(4))
    attractive_b=Market(F(22),F(2),F(3),F(3))
    weaker_b=Market(F(5),F(2),F(3),F(3))
    seeding={
        'no_destination_demand': optimize(F(18),poor_source,weaker_b,allow_tooling=False),
        'high_destination_full_pass_through':optimize(F(18),poor_source,attractive_b,allow_tooling=False),
        'high_destination_no_pass_through':optimize(F(18),poor_source,attractive_b,replace(s,pass_through=F(0)),allow_tooling=False),
        'high_destination_no_learning':optimize(F(18),poor_source,attractive_b,replace(s,learning_g=F(0),learning_s=F(0)),allow_tooling=False),
        'high_destination_redeployment_allowed':optimize(F(18),poor_source,attractive_b,allow_tooling=False,allow_redeployment=True),
    }
    return dict(cases=cases,thresholds=thresholds,source_seeding=seeding,base_inputs=dict(A=a,supply=s,initial_cash=F(14)),metadata='Synthetic exact finite capital allocation, not fitted economics')


def to_json(obj:Any):
    if isinstance(obj,F):return {'exact':str(obj),'approx':float(obj)}
    if hasattr(obj,'__dataclass_fields__'):return {k:to_json(v) for k,v in obj.__dict__.items()}
    if isinstance(obj,dict):return {k:to_json(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)):return [to_json(v) for v in obj]
    return obj

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='results.json')
    args=p.parse_args()
    with open(args.output,'w') as f:json.dump(to_json(scenarios()),f,sort_keys=True,indent=2);f.write('\n')
    print(args.output)
