# Original page sources

These five ReportLab scripts supplied the text, tables, equations and references for the two November 2026 PDF editions. The build uses the figures in the repository. Python dependencies are reportlab, Pillow, and PyMuPDF. The original renderer expects system-installed DejaVu Serif and Open Sans under /usr/share/fonts/truetype.

Extract the archive and run the following from its extracted directory, using the path to the repository's papers/autonomous_firm/figures directory.

    python build.py --figures /path/to/papers/autonomous_firm/figures --output ./rebuilt

The build recreates page content and layout. PDF metadata, bookmark entries and byte hashes can vary by publishing toolchain.
