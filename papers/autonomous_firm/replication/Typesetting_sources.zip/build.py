"""Rebuild the two PDF editions using the archived page sources and five checked-in figures."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

import fitz

SOURCES = Path(__file__).resolve().parent
FIGURES = {
    'theory_work/probe.png': 'probe.png',
    'theory_work/fleet.png': 'fleet.png',
    'theory_work/feedback.png': 'price_feedback.png',
    'sequence_work/regime.png': 'regime.png',
    'competition/feedback.png': 'competitive_feedback.png',
}
PAGES = [
    'theory_work/paper.py',
    'sequence_work/render_allocation.py',
    'sequence_work/note.py',
    'sequence_work/render_extension.py',
    'competition/render.py',
]


def build(figures, output):
    output.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory() as temporary:
        work = Path(temporary)
        for relative in PAGES:
            target = work / relative
            target.parent.mkdir(exist_ok=True)
            shutil.copyfile(SOURCES / relative, target)
        for relative, filename in FIGURES.items():
            shutil.copyfile(figures / filename, work / relative)
        for relative in PAGES:
            subprocess.run([sys.executable, str(work / relative)], cwd=work, check=True)
        shutil.copyfile(work / 'The_Autonomous_Firm.pdf', output / 'The_Autonomous_Firm.pdf')
        with fitz.open() as document:
            for part in ('sequence_work/allocation_pages.pdf', 'Choosing_the_First_Deployment.pdf',
                         'sequence_work/added_pages.pdf', 'competition/competition_pages.pdf'):
                with fitz.open(work / part) as source:
                    document.insert_pdf(source)
            assert len(document) == 17
            document.save(output / 'Choosing_the_First_Deployment.pdf', garbage=3, deflate=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figures', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    build(args.figures.resolve(), args.output.resolve())
