from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image
BASE=Path(__file__).resolve().parent
OUT=BASE.parent/'Choosing_the_First_Deployment.pdf'
for n,file in [('Serif','dejavu/DejaVuSerif.ttf'),('SerifB','dejavu/DejaVuSerif-Bold.ttf'),('Sans','open-sans/OpenSans-Regular.ttf'),('SansB','open-sans/OpenSans-Semibold.ttf'),('SansI','open-sans/OpenSans-Italic.ttf')]:
    pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/'+file))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='SansB',italic='SansI',boldItalic='SansB')
pdfmetrics.registerFontFamily('Serif',normal='Serif',bold='SerifB',italic='Serif',boldItalic='SerifB')
ink='#18303F'; grey='#475D67'; teal='#116C65'; rust='#A04730'; line='#B4C6C4'; pale='#EAF4F1'
C=canvas.Canvas(str(OUT),pagesize=(612,792),pageCompression=1)
C.setTitle('Choosing the First Deployment | Autonomous Firm Theory')
C.setAuthor('Autonomous Firm research • working paper prepared for Amar Murray')
M=48;W=516; y=0; page=0
def style(name,font='Sans',size=10.2,lead=15,color=ink):
    return ParagraphStyle(name,fontName=font,fontSize=size,leading=lead,textColor=HexColor(color),spaceAfter=0,allowWidows=0,allowOrphans=0)
def block(text,st=None,after=9):
    global y
    text=''.join('<font name="Serif">'+c+'</font>' if c in '₊→ᵢᵣₕ' else c for c in text)
    p=Paragraph(text,st or style('body')); _,h=p.wrap(W,800);p.drawOn(C,M,y-h);y-=h+after
def page_start(k,title,deck=''):
    global page,y
    if page: end()
    page+=1
    C.setStrokeColor(HexColor(line));C.line(M,746,M+W,746)
    C.setFont('SansB',8.3);C.setFillColor(HexColor(teal));C.drawString(M,755,'RESEARCH ON THE AUTONOMOUS FIRM')
    C.setFillColor(HexColor(grey));C.drawRightString(M+W,755,'RESEARCH NOTE   /   22 NOVEMBER 2026')
    y=721
    block(k.upper(),style('k','SansB',8.5,11,teal),6)
    block(title,style('t','Serif',24,30),8)
    if deck:block(deck,style('deck','Sans',11,16,grey),15)
def end():
    global y
    if y<34: raise RuntimeError(f'Overflow page {page}: {y}')
    print(f'p{page:02d} last baseline allowance {y:.1f}')
    C.setFont('Sans',8);C.setFillColor(HexColor(grey));C.drawString(M,25,'Autonomous Firm Theory   /   Exploratory paper');C.drawRightString(564,25,f'{page:02d}');C.showPage()
def h(t):block(t,style('h','SansB',12,15,teal),5)
def box(t):
    global y
    p=Paragraph(t,style('box','Serif',11.7,17)); _,height=p.wrap(W-26,800)
    C.setFillColor(HexColor(pale)); C.roundRect(M,y-height-20,W,height+20,5,fill=1,stroke=0)
    C.setFillColor(HexColor(teal));C.rect(M,y-height-20,3,height+20,fill=1,stroke=0)
    p.drawOn(C,M+13,y-height-10);y-=height+32
def cap(t):block(t,style('c','Sans',8.5,12,grey),9)
def fig(name,height):
    global y
    f=BASE/(name+'.png');iw,ih=Image.open(f).size;w=min(W,height*iw/ih);hh=w*ih/iw
    C.drawImage(str(f),M+(W-w)/2,y-hh,w,hh);y-=hh+5
def tab(rows,widths):
    global y
    data=[[Paragraph(str(cell),style('td','SansB' if i==0 else 'Sans',9.1,12.4,'#FFFFFF' if i==0 else ink)) for cell in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor(teal)),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#f1f6f5'),HexColor('#ffffff')]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),6)]))
    _,ht=t.wrap(W,700);t.drawOn(C,M,y-ht);y-=ht+12
def eq(t):block(t,style('eq','Serif',12.6,18,teal),10)
def ref(idx,title,url,claim):
    block(f'<font color="{teal}"><b>{idx} · <a href="{escape(url)}">{escape(title)}</a></b></font>  {escape(claim)}',style('ref','Sans',9.25,13.4),7)
page_start('Deployment economics','Choosing the First Deployment','How demand in one market changes the price of robot work in another')
box('A customer can become more valuable to a robotics firm even while its factory, orders and labor costs stay the same. Its production line teaches a recovery that another customer now has more reason to buy.')
block('Imagine a packaging line where a teleoperator occasionally recovers a carton whose flaps have folded inward. A second customer handles different goods but encounters the same fault. Tomorrow’s order at the second plant changes the value of observing that recovery today. At a sufficiently large order, it can reverse the deployment sequence altogether. The firm takes its engineers straight to the second plant.')
h('From robot productivity to demand')
block('At a customer site, the marginal product of robot capital is the extra accepted output from another unit of installed robot capacity, given the crew, line and work available. For a short-run quote, the relevant increment may be one more operating hour on an installed cell. Faster picks create little throughput value if the packer is already full. Covering a missing shift can unlock an entire shipment.')
block('The most the customer would pay for a block of service is its incremental operating profit against its best feasible alternative, measured before the robot fee. Count additional saleable units at contribution margin, labor expense actually avoided or the value of labor redeployed, and changes in rework and downtime. Count each gain once. A deployer that charges below that ceiling leaves the customer a reason to expand volume. The resulting workload determines which events the robot encounters.')
h('One launch slot, three uses')
block('Let A be the packaging site, B the target market, and C a routine deployment. The firm has one launch team for this window. At A it chooses q blocks of service at a uniform price p(q). Its current contribution is m(q). With probability g(q), the experience qualifies a reusable policy at B by the order deadline. Let V be the firm’s discounted contribution from a qualified B order, net of serving it. Going directly to B qualifies it with certainty at one-time cost F. Routine site C yields K.')
eq('Value of A = max<sub>q</sub> { m(q) + g(q)V }<br/>Value of direct B = V − F &nbsp;&nbsp;&nbsp;&nbsp; Value of C = K')
block('The firm chooses the highest feasible value, including zero for waiting. Both routes to B serve the same order on the same terms. Choosing C or waiting lets this order expire. If the firm can still launch B after a failed A pilot, the fallback belongs in A’s value. Adding the whole B order to both the transfer gain and that fallback would count it twice.',after=5)

page_start('Proposition  /  Site sequencing','When the learning site loses its place','The order can move from an ordinary deployment, to the learning site, to the target market itself.')
block('<b>Proposition.</b> Suppose feasible pilot sizes are finite and each has a positive chance of qualifying B, strictly below the direct route’s chance. As V rises, A gains against C and loses ground against direct B. If A is strictly best for any V, the values of V for which it wins form one interval. Inside it, if larger pilots are more likely to qualify B, the optimal pilot size weakly increases. With downward-sloping demand, the offered unit price weakly falls.')
block('<b>Derivation.</b> Each A plan has value m(q) + g(q)V. Every such line rises faster than the flat payoff K and more slowly than direct entry. The best A plan inherits both comparisons. Comparing two quantities, the larger pilot’s advantage rises by the difference in their qualification probabilities per extra unit of V. A quantity switch therefore favors the larger pilot as V rises.')
h('A worked deployment decision')
block('All figures are illustrative currency units. Set K = 76, F = 20 and p(q) = 24 − q for 1 through 12 blocks. Each block costs 8 and independently has a 10% chance of producing a recovery that passes the target test. One qualifying recovery suffices. Then m(q) = q(16 − q) and g(q) = 1 − 0.9<super>q</super>. Assume cross-site training rights and include collection, training and validation in the block cost.')
fig('regime',140)
cap('Figure 1. Expected contribution from starting at A minus the better of C and direct B. Above zero, A wins. The kink at V = 96 occurs when direct B overtakes C as the alternative use of the launch team.')
tab([['Target value V','Best first site','Blocks sold at A','Unit price at A','Firm value'],['0','C','—','—','76.00'],['22','A','8','16','76.53'],['100','A','10','14','125.13'],['250','Direct B','—','—','230.00']],[94,103,113,109,97])
block('A first ties C at V = 21.07. The first price cut comes later, at V = 23.23, when a ninth block earns its place. At V = 240.77 even the largest pilot’s remaining chance of missing the order outweighs A’s current margin plus the direct qualification cost saved. Above that point A loses the launch slot.',after=4)

page_start('Implications  /  Empirical design','What the firm has to learn','The uncertain quantity is the gain at a particular target from the next block of source work.')
h('Price an encounter, then choose how to obtain it')
block('For a differentiable interior choice with per-block cost c, the pricing condition is p(q) + q p′(q) = c − Vg′(q). The term Vg′(q) is what the firm would give up in immediate contribution for the extra chance of qualifying B. It can justify a volume discount at A even when A’s own productivity has stayed flat. If a discount fills the schedule with familiar cartons, g′ can be close to zero. Buying a targeted operator demonstration or a simulator run may then earn more than discounting a whole shift.')
block('In a fleet, g depends on which failures recur, who can correct them, available training and inference compute, and compatibility with the target embodiment. A logged intervention that cannot be reused or validated by the deadline may have considerable local service value and zero value for this B order. A change in gripper geometry may beat collecting another thousand examples. These alternatives belong in the same budget at the time each input is needed.')
h('Where organizational inventiveness enters')
block('Give two firms identical robots, policies and budgets. One sends every exception to a rescue queue. At the other, agents can reserve operator time, sample a particular fault at A, test the update at B and reassign the launch team. The firm retains both the carton policy and the procedure for deciding which fault deserves a demonstration. The second asset has a distinct test. Give both firms an unfamiliar pair of sites and the same starting policy and budget. Does the revised procedure choose experiments that deliver more accepted work per dollar?')
h('A test that could reject the mechanism')
block('Use a B-only change in booked orders or an externally set order deadline. Track the full menu of candidate sites, including lost bids and unused slots. Estimate transferable lift from held-out B runs with and without A examples at matched compute, task mix and hardware. Record accepted throughput, operator minutes, displaced launch work and realized contribution. Compare source sites with similar local demand but different measured transfer to B.')
block('A moderate B shock can lower A’s price or move A ahead of C. A larger shock can move the team directly to B. Comparable discounts at sites with no reusable transfer would favor another explanation, such as a common demand shock. An extra launch team should weaken the competition between routes.')
h('Research antecedents')
ref('1','Farboodi, Koh & Xia · Data-Driven Automation (2026)','https://www.nber.org/papers/w35320','Models task-specific data produced by economic activity and spillovers across tasks.')
ref('2','Open X-Embodiment Collaboration · RT-X models (2023)','https://arxiv.org/abs/2310.08864','Demonstrates positive cross-robot transfer in tested settings. A commercial qualification rate still requires site-level evidence.')
ref('3','Spence · The Learning Curve and Competition (1981)','https://www.gsb.stanford.edu/faculty-research/publications/learning-curve-competition','Develops the economics of output and learning. Here the deployment decision also includes direct qualification at the destination.')
end()
C.save()
