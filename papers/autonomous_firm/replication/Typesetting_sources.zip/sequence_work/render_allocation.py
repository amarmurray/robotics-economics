from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image
BASE=Path(__file__).resolve().parent
OUT=BASE/'allocation_pages.pdf'
for n,file in [('Serif','dejavu/DejaVuSerif.ttf'),('SerifB','dejavu/DejaVuSerif-Bold.ttf'),('Sans','open-sans/OpenSans-Regular.ttf'),('SansB','open-sans/OpenSans-Semibold.ttf'),('SansI','open-sans/OpenSans-Italic.ttf')]:
    pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/'+file))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='SansB',italic='SansI',boldItalic='SansB')
pdfmetrics.registerFontFamily('Serif',normal='Serif',bold='SerifB',italic='Serif',boldItalic='SerifB')
ink='#18303F'; grey='#475D67'; teal='#116C65'; rust='#A04730'; line='#B4C6C4'; pale='#EAF4F1'
C=canvas.Canvas(str(OUT),pagesize=(612,792),pageCompression=1)
C.setTitle('Choosing the First Deployment | Autonomous Firm Theory')
C.setAuthor('Autonomous Firm research • working paper prepared for Amar Murray')
M=48;W=516; y=0; page=0
def style(name,font='Sans',size=10.2,lead=15,color=ink):
    return ParagraphStyle(name,fontName=font,fontSize=size,leading=lead,textColor=HexColor(color),spaceAfter=0,allowWidows=0,allowOrphans=0)
def block(text,st=None,after=9):
    global y
    text=''.join('<font name="Serif">'+c+'</font>' if c in '₊→ᵢᵣₕ' else c for c in text)
    p=Paragraph(text,st or style('body')); _,h=p.wrap(W,800);p.drawOn(C,M,y-h);y-=h+after
def page_start(k,title,deck=''):
    global page,y
    if page: end()
    page+=1
    C.setStrokeColor(HexColor(line));C.line(M,746,M+W,746)
    C.setFont('SansB',8.3);C.setFillColor(HexColor(teal));C.drawString(M,755,'RESEARCH ON THE AUTONOMOUS FIRM')
    C.setFillColor(HexColor(grey));C.drawRightString(M+W,755,'RESEARCH NOTE   /   22 NOVEMBER 2026')
    y=721
    block(k.upper(),style('k','SansB',8.5,11,teal),6)
    block(title,style('t','Serif',24,30),8)
    if deck:block(deck,style('deck','Sans',11,16,grey),15)
def end():
    global y
    if y<34: raise RuntimeError(f'Overflow page {page}: {y}')
    print(f'p{page:02d} last baseline allowance {y:.1f}')
    C.setFont('Sans',8);C.setFillColor(HexColor(grey));C.drawString(M,25,'Autonomous Firm Theory   /   Exploratory paper');C.drawRightString(564,25,('i','ii','iii')[page-1]);C.showPage()
def h(t):block(t,style('h','SansB',12,15,teal),5)
def box(t):
    global y
    p=Paragraph(t,style('box','Serif',11.7,17)); _,height=p.wrap(W-26,800)
    C.setFillColor(HexColor(pale)); C.roundRect(M,y-height-20,W,height+20,5,fill=1,stroke=0)
    C.setFillColor(HexColor(teal));C.rect(M,y-height-20,3,height+20,fill=1,stroke=0)
    p.drawOn(C,M+13,y-height-10);y-=height+32
def cap(t):block(t,style('c','Sans',8.5,12,grey),9)
def fig(name,height):
    global y
    f=BASE/(name+'.png');iw,ih=Image.open(f).size;w=min(W,height*iw/ih);hh=w*ih/iw
    C.drawImage(str(f),M+(W-w)/2,y-hh,w,hh);y-=hh+5
def tab(rows,widths):
    global y
    data=[[Paragraph(str(cell),style('td','SansB' if i==0 else 'Sans',9.1,12.4,'#FFFFFF' if i==0 else ink)) for cell in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor(teal)),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#f1f6f5'),HexColor('#ffffff')]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),6)]))
    _,ht=t.wrap(W,700);t.drawOn(C,M,y-ht);y-=ht+12
def eq(t):block(t,style('eq','Serif',12.6,18,teal),10)
def ref(idx,title,url,claim):
    block(f'<font color="{teal}"><b>{idx} · <a href="{escape(url)}">{escape(title)}</a></b></font>  {escape(claim)}',style('ref','Sans',9.25,13.4),7)
page_start('Autonomous Firm Theory  /  Allocation','What does the firm allocate?','A theory of how a firm commits scarce capacity when doing the work also changes what its agents can learn and do next.')
box('The unit of allocation is a feasible plan for using capacity over time. “Give an operator an hour at A” is an incomplete description. Its value depends on what the operator could otherwise do, what the hour might reveal, and who could use that evidence before it expires.')
h('Four primitives')
block('<b>1. Work and payoffs.</b> A task has a customer, an acceptance condition and a deadline. Completed work earns the contribution the firm can capture. A faster robot changes that contribution if it affects accepted throughput, cost, or the price the customer will pay. An internal charge moves money between units and cancels at the firm level.')
block('<b>2. Feasible combinations.</b> Specify which agent, embodiment, operator, compute and permissions a plan needs, where, and in which window. An operator today and validation compute tomorrow can be complements. An unrelated inference job tomorrow can compete for that same compute. Competition for capacity and transfer of learning are different relationships between tasks.')
block('<b>3. Information and authority.</b> Each decision belongs to someone who can observe particular signals and commit particular inputs before a deadline. A plan may say “validate if the trace is informative and the queue is light” only if an authorized actor can learn both facts in time. Delegation or a contingent contract can change this feasible set.')
block('<b>4. State transitions.</b> A choice produces work, selects the observations the firm will see, and can alter the policy, hardware or procedures available next time. Distinguish a change in the firm’s belief about a gripper from a retrofit that physically changes its reach. Both can change the next decision through different channels.')
h('The governing comparison')
eq('Q(s, a) = E[π + β J(s′) | s, a] &nbsp;&nbsp;&nbsp; J(s) = max over feasible a of Q(s, a)')
block('Here s records payoff-relevant productive capacity, outstanding commitments and beliefs. A choice a is a feasible joint plan up to the next decision, including who can respond to which signal. π is net contribution over that interval. J is the value of reallocating optimally thereafter. To value a commitment, compare the best plan requiring it with the best plan excluding it. Both comparisons allow the rest of the firm to adapt. A forecast of future orders enters once through the payoffs it changes.')
cap('This is a normative benchmark. The empirical question is which constraints and transitions explain observed choices. The deployment study that follows uses its own page numbering.')

page_start('Allocation  /  A derived implication','When the timing of scarcity changes the answer','Two firms can have identical demand, robots, error rates, teleoperator costs and available compute, yet rationally collect different data.')
block('An operator can handle a paying job today or sample a fault at site A. Sampling gives up k in contribution. With probability one half it yields a usable trace (I = 1). Tomorrow, validating that trace delivers target contribution v by the deadline. It consumes a slot otherwise earning X on another job. Without a trace the other job runs. The authorized scheduler observes I and X before committing the slot. All amounts are in present-value units.')
eq('Gain from sampling = E[I × max(v − X, 0)] − k')
block('Suppose k = 7, v = 24, and the alternative job earns either 2 or 18 with equal probability. The slot is always worth using when there is a trace. The two schedules differ solely in which state coincides with a usable trace.')
tab([['Timing of useful traces','Alternative displaced when I = 1','Gain from sampling','Allocate operator to'],['All arrive in quiet windows','2','½(24 − 2) − 7 = +4','Sampling'],['Timing is independent','10 on average','½(24 − 10) − 7 = 0','Either use'],['All arrive in busy windows','18','½(24 − 18) − 7 = −4','Paying job']],[144,124,142,106])
h('Why a site-level score misses the reversal')
block('In this range the gain is Pr(I = 1) × (v − E[X]) − Cov(I, X) − k. A score built from average transfer yield, average compute utilization and target value gives zero in all three rows. The omitted covariance gives the entire ranking here. With higher congestion the option to decline validation also matters. The positive-part formula continues to hold when the covariance shortcut fails.')
block('An operating prediction follows. Retiming an unrelated batch job, without adding compute or improving the model, can make a previously rejected demonstration worth collecting. The prediction requires a shared, deadline-bound slot. If traces can wait costlessly until spare capacity arrives, the relevant alternative is whatever that later slot would displace. The immediate congestion effect can disappear.')
h('A test at the level of the firm')
block('Randomize and announce eligible batch-job schedules before sampling decisions, holding total capacity and booked work fixed. Record the trace yield with occasional assigned sampling shifts, including windows the controller would normally skip. Then observe its discretionary sampling choices, accepted target work and displaced jobs. This tests a change in the allocation ranking and the firm-wide contribution it predicts. Samples gathered only on chosen shifts would confound the decision with the evidence used to evaluate it.')

page_start('Allocation  /  Organizational implications','How allocation produces firm differences','A price concession, a persistent deployment route and a valuable routine can all arise from the same allocation rule.')
h('Decision rights can reverse an investment')
block('In a variant of the timing example, take v = 12, k = 2 and let trace arrival be independent of the queue. If an authorized scheduler sees the queue, it validates only in a quiet window. Sampling earns ¼ × (12 − 2) − 2 = +0.50. If the validator must commit upon receiving a trace, before seeing the queue, validation then earns 12 − 10 = 2 on average. Ex ante, sampling earns ½ × 2 − 2 = −1. The firm allocates the operator elsewhere. A timely message and the power to act on it can therefore induce upstream data collection with exactly the same machines and staff.')
h('Three mechanisms emerge at different timescales')
block('<b>Within a window,</b> relative advantage depends on the best use of shared inputs. A shift in queue timing changes what the firm should sample even if every model’s accuracy is fixed. A scalar price for a slot can coordinate this example if it conveys the actual displaced value in time and the local agent also receives credit for downstream gains.')
block('<b>Across orders,</b> customer demand changes the payoff to a successful transfer. The deployment study derives the sequence from routine work, to a source pilot, to direct entry. The last switch requires a more reliable direct route and competition for a launch slot. Firms with ample launch capacity can pursue both routes.')
block('<b>Across cohorts,</b> the allocation can change the transition that governs later allocations. Maintaining a capture routine raises the yield of the next operator-hour. If the firm can profit from that yield, it may spend another hour maintaining the routine. Depreciation, weak transfer or a better outside job can end this feedback. The study’s two-state example gives a finite period of persistence after a demand shock.')
h('When a resource-based theory becomes warranted')
block('Start two firms with the same purchasable inputs and opportunities. Vary an earlier allocation, then equalize demand and current budgets. Which retained difference still changes the set of profitable plans? For a capture routine, measure its effect on trace yield, remove or restore it, and re-optimize the whole firm in each case. Its economic value is the resulting difference in attainable profit. Durable private advantage requires an additional account of control, replication cost and who captures the gain. A temporary congestion price can govern allocation without becoming an accumulated resource.')
block('This yields a candidate firm-specific resource only if the retained difference survives into a new decision. It is endogenous if earlier choices helped form it and heterogeneous if firms facing the same opportunity inherit different levels. Two complementary routines may be valuable only together. Their separately measured marginal values need not add up to the value of the pair.')
cap('Intellectual antecedents. Koopmans develops production as combinations of activities. Marschak and Radner make information and decision functions features of organization. Penrose connects inherited resources to the productive services a firm can render. The timing test and the numerical comparisons here are illustrative deductions.')
block('<a href="https://cowles.yale.edu/research/cfm-13-activity-analysis-production-and-allocation">Activity Analysis of Production and Allocation</a>  ·  <a href="https://cowles.yale.edu/research/cfm-22-economic-theory-teams">Economic Theory of Teams</a>  ·  <a href="https://academic.oup.com/book/25306/1000">The Theory of the Growth of the Firm</a>',style('links','Sans',8,11,teal),1)
end()
C.save()
