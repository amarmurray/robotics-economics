from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image
BASE=Path(__file__).resolve().parent
OUT=BASE/'added_pages.pdf'
for n,file in [('Serif','dejavu/DejaVuSerif.ttf'),('SerifB','dejavu/DejaVuSerif-Bold.ttf'),('Sans','open-sans/OpenSans-Regular.ttf'),('SansB','open-sans/OpenSans-Semibold.ttf'),('SansI','open-sans/OpenSans-Italic.ttf')]:
    pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/'+file))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='SansB',italic='SansI',boldItalic='SansB')
pdfmetrics.registerFontFamily('Serif',normal='Serif',bold='SerifB',italic='Serif',boldItalic='SerifB')
ink='#18303F'; grey='#475D67'; teal='#116C65'; rust='#A04730'; line='#B4C6C4'; pale='#EAF4F1'
C=canvas.Canvas(str(OUT),pagesize=(612,792),pageCompression=1)
C.setTitle('Choosing the First Deployment | Autonomous Firm Theory')
C.setAuthor('Autonomous Firm research • working paper prepared for Amar Murray')
M=48;W=516; y=0; page=0
def style(name,font='Sans',size=10.2,lead=15,color=ink):
    return ParagraphStyle(name,fontName=font,fontSize=size,leading=lead,textColor=HexColor(color),spaceAfter=0,allowWidows=0,allowOrphans=0)
def block(text,st=None,after=9):
    global y
    text=''.join('<font name="Serif">'+c+'</font>' if c in '₊→ᵢᵣₕ' else c for c in text)
    p=Paragraph(text,st or style('body')); _,h=p.wrap(W,800);p.drawOn(C,M,y-h);y-=h+after
def page_start(k,title,deck=''):
    global page,y
    if page: end()
    page+=1
    C.setStrokeColor(HexColor(line));C.line(M,746,M+W,746)
    C.setFont('SansB',8.3);C.setFillColor(HexColor(teal));C.drawString(M,755,'RESEARCH ON THE AUTONOMOUS FIRM')
    C.setFillColor(HexColor(grey));C.drawRightString(M+W,755,'RESEARCH NOTE   /   22 NOVEMBER 2026')
    y=721
    block(k.upper(),style('k','SansB',8.5,11,teal),6)
    block(title,style('t','Serif',24,30),8)
    if deck:block(deck,style('deck','Sans',11,16,grey),15)
def end():
    global y
    if y<34: raise RuntimeError(f'Overflow page {page}: {y}')
    print(f'p{page:02d} last baseline allowance {y:.1f}')
    C.setFont('Sans',8);C.setFillColor(HexColor(grey));C.drawString(M,25,'Autonomous Firm Theory   /   Exploratory paper');C.drawRightString(564,25,f'{page:02d}');C.showPage()
def h(t):block(t,style('h','SansB',12,15,teal),5)
def box(t):
    global y
    p=Paragraph(t,style('box','Serif',11.7,17)); _,height=p.wrap(W-26,800)
    C.setFillColor(HexColor(pale)); C.roundRect(M,y-height-20,W,height+20,5,fill=1,stroke=0)
    C.setFillColor(HexColor(teal));C.rect(M,y-height-20,3,height+20,fill=1,stroke=0)
    p.drawOn(C,M+13,y-height-10);y-=height+32
def cap(t):block(t,style('c','Sans',8.5,12,grey),9)
def fig(name,height):
    global y
    f=BASE/(name+'.png');iw,ih=Image.open(f).size;w=min(W,height*iw/ih);hh=w*ih/iw
    C.drawImage(str(f),M+(W-w)/2,y-hh,w,hh);y-=hh+5
def tab(rows,widths):
    global y
    data=[[Paragraph(str(cell),style('td','SansB' if i==0 else 'Sans',9.1,12.4,'#FFFFFF' if i==0 else ink)) for cell in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor(teal)),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#f1f6f5'),HexColor('#ffffff')]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),6)]))
    _,ht=t.wrap(W,700);t.drawOn(C,M,y-ht);y-=ht+12
def eq(t):block(t,style('eq','Serif',12.6,18,teal),10)
def ref(idx,title,url,claim):
    block(f'<font color="{teal}"><b>{idx} · <a href="{escape(url)}">{escape(title)}</a></b></font>  {escape(claim)}',style('ref','Sans',9.25,13.4),7)
page=3
# Start a separate PDF with the same page numbering and style.
base_start=page_start
page=0
base_start('Extension  /  Conjecture','When demand changes what the firm can learn','Two launch teams can face identical orders and rationally choose opposite sites because their earlier deployments changed what each team can learn in a shift.')
page=4
box('Conjecture. When deployments build a reusable way to collect target-relevant evidence, a temporary order at B can change the firm’s choice of site after the order expires. A large enough order can interrupt the very learning process that a smaller order would sustain.')
h('What survives a deployment?')
block('Suppose every launch window brings a fresh carton variant at B. Each requires a new acceptance test. A capture routine at A synchronizes the operator’s correction with camera frames from just before a jam. The routine can carry across variants even when the correction itself cannot. Teams that use it have occasions to fix a misaligned camera or update a trigger. Idle routines can fall behind changing equipment. A direct launch at B solves that order locally.')
block('Call the capture routine <b>ready</b> if a standard test confirms it works and <b>unready</b> otherwise. Freeze the execution policy, hardware and training budget across teams. Retain the margins, prices and 12-block limit on page 2. Assume each block at A independently qualifies the current B order with probability .12 when ready and .06 otherwise. The next routine state depends on the route, with probabilities below. These are illustrative assumptions about maintenance and discovery.')
tab([['Current routine','Ready next window after A','Ready next window after B or C'],['Unready','25%','0%'],['Ready','95%','65%']],[114,188,214])
h('The decision has two distinct payoffs from learning')
block('Let Δ be next window’s expected lifetime profit when ready minus that when unready. At a discount factor of .90, A’s advantage over the best other site equals its current advantage plus .90 × Δ × the extra probability of readiness from choosing A. Current advantage includes any B order qualified this window. Δ starts with the next order. This timing separates the value of a reusable collection method from the value of the specific policy it helped qualify.')
block('With future orders worth 250 each, the stationary solution gives Δ = 97.12. An unready team goes directly to B each window and earns 230. A ready team chooses 12 blocks at A, earns 244.08 in expectation this window and stays ready with probability .95. Subtracting the two lifetime values gives Δ = 14.08 / (1 − .90 × .95), up to rounding. Checking the alternative actions gives the strict choices on the next page.')

page_start('Extension  /  Predictions and identification','After the order expires','A one-window change in demand separates the value of today’s job from the ability to learn on tomorrow’s.')
block('Let only the current B order vary. Both teams know future orders return to 250. Each cell below is A’s advantage over the best alternative, including continuation value. Positive means launch at A. The final column gives the next-window chance of choosing A for a team starting unready / ready. At the common future demand of 250, only a ready team chooses A.')
tab([['B order now','A advantage if unready','A advantage if ready','Sites chosen now¹','A next window¹'],['0','+9.85','+14.22','A / A','25% / 95%'],['100','+47.99','+78.37','A / A','25% / 95%'],['250','−29.13','+40.30','B / A','0% / 95%'],['500','−148.11','−13.61','B / B','0% / 65%']],[77,103,100,118,118])
cap('¹ Ordered as initially unready / ready. Values use all 12 possible A volumes and both outside sites. At V = 0, C is the best outside site. At the other values, direct B is the best outside site.')
h('Two observations that the one-order model misses')
block('<b>A firm may pay to practice during a demand lull.</b> At zero current B demand, A earns 64 on its own work and C earns 76. An unready firm gives up 12 to buy a 25% chance of having a better sampling method next window. The discounted gain is 21.85. A lull can therefore be a good time to build the capacity that a busy launch calendar consumes.')
block('<b>The effect survives the shock and decays.</b> Compare two initially ready teams. One receives a B order worth 500 this window, the other 250. Next window both face 250. The first is 30 percentage points less likely to choose A. One window later the gap is 28.5 points. After k more ordinary windows the original gap is multiplied by .95<super>k</super>. Both teams eventually lose readiness here because an unready team at 250 never rebuilds. The model generates persistence with a finite expected duration.')
h('How to distinguish learning from customer inertia')
block('Hold initial readiness fixed and use a B-specific order shock with a known expiry. After demand normalizes, give teams the same previously unseen carton variant, execution policy, operator hours and training compute. Measure usable pre-jam traces per shift, qualification on held-out B cartons and the next site chosen. A shift in deployment alone could reflect installation costs or contract renewal. A change in trace yield and transfer on the common test is the additional prediction.')
block('A sharper intervention restores the capture routine to a random subset of interrupted teams before the next decision. The predicted route gap shrinks as measured readiness converges. If direct launches maintain the routine equally well, the continuation premium from choosing A vanishes. If restoring readiness fixes trace yield but leaves the entire deployment gap intact, another mechanism is governing site choice.')
end()
C.save()
